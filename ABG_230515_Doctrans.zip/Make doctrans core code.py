# Made by Gavin Crump
# Free for use
# BIM Guru, www.bimguru.com.au

# Boilerplate text
import clr

clr.AddReference("RevitServices")
import RevitServices
from RevitServices.Persistence import DocumentManager 

clr.AddReference("RevitAPI")
import Autodesk 
from Autodesk.Revit.DB import *

# Current doc/app/ui
doc = DocumentManager.Instance.CurrentDBDocument

# Define list/unwrap list functions
def uwlist(input):
    result = input if isinstance(input, list) else [input]
    return UnwrapElement(result)

# Preparing input from dynamo to revit
sheets = uwlist(IN[0])

# Get revision sequences and revisions
revSeqs = FilteredElementCollector(doc).OfClass(RevisionNumberingSequence).ToElements()
revIds  = Revision.GetAllRevisionIds(doc)
revs    = [doc.GetElement(i) for i in revIds]

# Get sequence name per revision


# Empty variable lists to store to
revSeqNames, revCharSeqs = [],[]

# Get sequence names and characters
for r in revs:
	# Get sequence
	rsId = r.RevisionNumberingSequenceId
	rs   = doc.GetElement(rsId)
	# Append the name and start a sequence
	revSeqNames.append(rs.Name)
	charSequence = []
	# Get sequence characters for numeric...
	if rs.NumberType == RevisionNumberType.Numeric:
		settings  = rs.GetNumericRevisionSettings()
		minDigits = settings.MinimumDigits
		prefix    = settings.Prefix
		suffix    = settings.Suffix
		for n in range(settings.StartNumber,99,1):
			char_str = str(n)
			pad_str  = char_str.rjust(minDigits,"0")
			char_seq = prefix + pad_str + suffix
			charSequence.append(char_seq)
	# ... or Alphanumeric
	else:
		settings = rs.GetAlphanumericRevisionSettings()
		prefix    = settings.Prefix
		suffix    = settings.Suffix
		for a in settings.GetSequence():
			char_seq = prefix + a + suffix
			charSequence.append(char_seq)
	# Append the character sequence
	revCharSeqs.append(charSequence)

# Get revision sequences per sheet
rowsOut = []
sep = "\t"

for s in sheets:
	trackRevs = []
	sheetRevs = s.GetAllRevisionIds()
	rowOut = ""
	rowOut += s.SheetNumber + sep + s.Name + sep
	# For each revision in the document
	for i in revIds:
		# Check if the sheet has it
		if i in sheetRevs:
			# Get the sequence Id name and get its name
			r    = doc.GetElement(i)
			rsId = r.RevisionNumberingSequenceId
			rs   = doc.GetElement(rsId)
			rsn  = rs.Name
			# Find the index of the sequence name
			i_sq = revSeqNames.index(rsn)
			# Find out how many times the sequence occured so far
			i_ch = trackRevs.count(rsn)
			# Get the sequence character, then track the sequence
			d = revCharSeqs[i_sq][i_ch] + sep
			trackRevs.append(rsn)
		else:
			d = "" + sep
		rowOut += d
	# Add the value to the end
	rowsOut.append(rowOut)


# Make the top header
header = "Number" + sep + "Name" + sep + sep.join([r.RevisionDate for r in revs]) + sep
rowsOut.insert(0,header)

# Preparing output to Dynamo
OUT = rowsOut