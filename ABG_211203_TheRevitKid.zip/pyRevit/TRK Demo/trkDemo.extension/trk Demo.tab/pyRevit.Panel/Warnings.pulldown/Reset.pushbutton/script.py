# import
# from pyrevit import script
from pyrevit import revit,DB
import clr
from Autodesk.Revit.DB import Transaction

# get document
doc = revit.doc
curview = revit.active_view

# try to disable temporary hide isolate

t = Transaction(doc, "Disable temp hide")

t.Start()

try:
    curview.DisableTemporaryViewMode(DB.TemporaryViewMode.TemporaryHideIsolate)
except:
    pass

t.Commit()