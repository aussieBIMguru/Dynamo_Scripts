print("Hello, this is working!")

try:
    variable_sum = "5" + 3
    print("Hello, this is working!")
except:
    print("That didn't work!")